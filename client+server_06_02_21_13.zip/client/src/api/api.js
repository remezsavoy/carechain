import axios from "axios";

const API = axios.create({
    baseURL: "http://localhost:5000",
    withCredentials: true // מאפשר שליחת cookies עם כל בקשה
});

export const register = async (userData) => {
    return API.post("/register", userData);
};

export const sendResetToken = async (email) => {
    return API.post("/forgot-password", { email });
};

export const verifyToken = async ({ email, token }) => {
    return API.post("/verify-token", { email, token });
};

export const resetPassword = async ({ email, token, newPassword }) => {
    return API.post("/reset-password", { email, token, newPassword });
};

export const login = async (email, password) => {
    return API.post("/login", { email, password });
};

export const logout = async () => {
    return API.post("/logout");
};


// 🔹 שליפת כל החוזים של רופא לפי `doctorId`
// 🔹 שליפת כל החוזים של רופא לפי `doctorId`
// ✅ קבלת רשימת חוזים של רופא
export const getContractsByDoctor = async (doctorId) => {
    try {
        const response = await API.get(`/contracts/doctor/${doctorId}`);
        console.log("✅ Fetched Contracts:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error fetching contracts:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ אישור חוזה
export const approveContract = async (contractId) => {
    try {
        const response = await API.put(`/contracts/${contractId}/approve`);
        console.log("✅ Contract approved:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error approving contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ עדכון חוזה
export const updateContract = async (contractId, updatedData) => {
    try {
        const response = await API.put(`/contracts/${contractId}`, updatedData);
        console.log("✅ Contract updated:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error updating contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ יצירת חוזה חדש
export const createContract = async (contractData) => {
    try {
        const response = await API.post("/contracts", contractData);
        console.log("✅ New Contract Created:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error creating contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ קבלת פרטי משתמש (לשליפת doctorId)
export const getUserDetails = async () => {
    return await API.get("/user-details"); // ✅ שינוי הנתיב
};



// ✅ קבלת חוזים לפי מטופל
export const getContractsByPatient = async (patientId) => {
    try {
        const response = await API.get(`/contracts/patient/${patientId}`);
        console.log("✅ Fetched Contracts for Patient:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error fetching contracts for patient:", error.response?.data || error.message);
        throw error;
    }
};

// A D M I N

// 🔹 שליפת כל המשתמשים
export const getUsers = async () => {
    try {
        const response = await API.get("/api/users");
        console.log("✅ Fetched Users:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error fetching users:", error.response?.data || error.message);
        throw error;
    }
};

// 🔹 יצירת משתמש חדש
export const createUser = async (userData) => {
    try {
        const response = await API.post("/api/users", userData);
        console.log("✅ User Created:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error creating user:", error.response?.data || error.message);
        throw error;
    }
};

// 🔹 עדכון פרטי משתמש
export const updateUser = async (userId, updatedData) => {
    try {
        const response = await API.put(`/api/users/${userId}`, updatedData);
        console.log("✅ User Updated:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error updating user:", error.response?.data || error.message);
        throw error;
    }
};

// 🔹 מחיקת משתמש
export const deleteUser = async (userId) => {
    try {
        const response = await API.delete(`/api/users/${userId}`);
        console.log("✅ User Deleted:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error deleting user:", error.response?.data || error.message);
        throw error;
    }
};

// A D M I N
export const getContracts = async () => {
    const response = await API.get("/api/contracts");
    return response.data;
};

export const deleteContract = async (contractId) => {
    return API.put(`/contracts/delete/${contractId}`);
};

export const restoreContract = async (contractId) => {
    return API.put(`/contracts/${contractId}/restore`);
};

export const toggleUserActive = async (userId, isActive) => {
    await API.put(`/api/users/${userId}/toggle-active`, { active: isActive });
};

export const getUserById = async (patientId) => {
    const response = await API.get(`/api/users/${patientId}`);
    return response.data;
};

// APPOITMENTS

export const createAppointment = async (appointmentData) => {
    return await API.post("/api/appointments", appointmentData);
};

export const getAppointmentsByDoctor = async (doctorId) => {
    const response = await API.get(`/api/appointments/doctor/${doctorId}`);
    return response.data;
};

export const cancelAppointment = async (appointmentId) => {
    return await API.put(`/api/appointments/${appointmentId}/cancel`);
};

export const toggleAppointmentStatus = async (appointmentId, canceled) => {
    try {
        const response = await API.put(`/api/appointments/${appointmentId}/toggle`, { canceled });
        return response.data;
    } catch (error) {
        console.error("Error toggling appointment status:", error);
        throw error;
    }
};


