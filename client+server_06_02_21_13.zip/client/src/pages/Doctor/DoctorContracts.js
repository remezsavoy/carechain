import React, { useState, useEffect } from "react";
import { getContractsByDoctor, getUserDetails, getUserById } from "../../api/api";
import "./DoctorContracts.css"; // ✅ קישור לקובץ העיצוב

const DoctorContracts = () => {
    const [contracts, setContracts] = useState([]);
    const [error, setError] = useState("");
    const [doctorId, setDoctorId] = useState("");
    const [selectedContract, setSelectedContract] = useState(null);
    const [patientName, setPatientName] = useState("");
    const [searchTerm, setSearchTerm] = useState("");

    // Fetch details of the logged-in user
    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await getUserDetails();
                setDoctorId(response.data.idNumber);
            } catch (err) {
                setError("Failed to fetch user details.");
            }
        };
        fetchUserDetails();
    }, []);

    // Fetch contracts of the doctor
    const fetchContracts = async () => {
        try {
            const data = await getContractsByDoctor(doctorId);
            setContracts(data);
        } catch (err) {
            setError("Failed to load contracts.");
        }
    };

    useEffect(() => {
        if (!doctorId) return;
        fetchContracts();
    }, [doctorId]);

    // Fetch patient name by patient ID
    const fetchPatientName = async (patientId) => {
        try {
            const response = await getUserById(patientId);
            if (response) {
                setPatientName(`${response.firstName} ${response.lastName}`);
            } else {
                setPatientName("Unknown");
            }
        } catch (error) {
            console.error("Failed to fetch patient name", error);
            setPatientName("Unknown");
        }
    };

    const handleViewContract = async (contract) => {
        setSelectedContract(contract);
        await fetchPatientName(contract.patientId);
    };

    // Filter contracts based on search term
    const filteredContracts = contracts.filter(contract =>
        contract.contractId?.toString().includes(searchTerm) ||
        contract.patientId?.toString().includes(searchTerm) ||
        contract.treatmentType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        contract.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="contracts-container">
            <h2>Doctor Contracts</h2>
            {error && <p className="error-message">{error}</p>}

            <input
                type="text"
                className="search-bar"
                placeholder="🔎 Search contracts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />

            {filteredContracts.length === 0 ? (
                <p>No contracts found.</p>
            ) : (
                <div className="table-wrapper">
                    <table className="contracts-table">
                        <thead>
                        <tr>
                            <th>Contract ID</th>
                            <th>Patient ID</th>
                            <th>Treatment</th>
                            <th>Description</th>
                            <th>Approved</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {filteredContracts.map((contract) => (
                            <tr key={contract.contractId}>
                                <td>{contract.contractId}</td>
                                <td>{contract.patientId}</td>
                                <td>{contract.treatmentType}</td>
                                <td>{contract.description}</td>
                                <td className={contract.isApproved ? "contract-approved" : "contract-not-approved"}>
                                    {contract.isApproved ? "✅ Yes" : "❌ No"}
                                </td>
                                <td>
                                    <button className="view-button" onClick={() => handleViewContract(contract)}>
                                        👁 View
                                    </button>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            )}

            {selectedContract && (
                <div className="popup-overlay">
                    <div className="popup-content">
                        <h3>Contract Details</h3>
                        <p><strong>Contract ID:</strong> {selectedContract.contractId}</p>
                        <p><strong>Patient ID:</strong> {selectedContract.patientId}</p>
                        <p><strong>Patient Name:</strong> {patientName}</p>
                        <p><strong>Treatment Type:</strong> {selectedContract.treatmentType}</p>
                        <p><strong>Description:</strong> {selectedContract.description}</p>
                        <button onClick={() => setSelectedContract(null)} className="close-popup-button">Close</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DoctorContracts;