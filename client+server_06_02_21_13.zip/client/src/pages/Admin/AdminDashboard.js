import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../../api/api";
import "./AdminDashboard.css";

export default () => {
    const navigate = useNavigate();
    const [error, setError] = useState(null);

    // בדיקת אימות כאשר הרכיב נטען
    useEffect(() => {
        const checkAuth = async () => {
            try {
                const response = await fetch("http://localhost:5000/auth-check", {
                    method: "GET",
                    credentials: "include", // שולח את ה-cookie עם הבקשה
                });

                if (response.status !== 200) {
                    throw new Error("Not authenticated");
                }
            } catch (error) {
                // אם המשתמש לא מאומת, נעבור לעמוד ההתחברות
                setError("Authentication failed. Redirecting to login...");
                setTimeout(() => navigate("/login"), 2000);
            }
        };

        checkAuth();
    }, [navigate]);

    const handleLogout = async () => {
        try {
            await logout(); // קריאת פונקציית logout
            navigate("/"); // מעבר לעמוד הבית
        } catch (error) {
            console.error("Logout failed:", error);
        }
    };

    return (
        <div className="dashboard-container">
            <header className="dashboard-header">
                <h1>Welcome to CareChain</h1>
                <h2>You are logged in as an Admin</h2>
                <p>Your secure medical management platform</p>
                <button onClick={handleLogout} className="logout-button">Logout</button>
            </header>

            {error && <div className="error-message">{error}</div>}

            <div className="dashboard-content">
                <div className="dashboard-card">
                    <h2>My Profile</h2>
                    <p>View and edit your personal information</p>
                    <Link to="/profile" className="dashboard-button">Go to Profile</Link>
                </div>

                <div className="dashboard-card">
                    <h2>Settings</h2>
                    <p>Adjust your account and notification settings</p>
                    <Link to="/settings" className="dashboard-button">Settings</Link>
                </div>

                {/* כרטיסייה חדשה: ניהול משתמשים */}
                <div className="dashboard-card">
                    <h2>User Management</h2>
                    <p>Add, edit, and delete users</p>
                    <Link to="/user-management" className="dashboard-button">Manage Users</Link>
                </div>

                {/* כרטיסייה חדשה: צפייה בחוזים רפואיים */}
                <div className="dashboard-card">
                    <h2>View Medical Contracts</h2>
                    <p>Explore and review detailed contract information</p>
                    <Link to="/view-contracts" className="dashboard-button">View Contracts</Link>
                </div>

                {/* כרטיסייה חדשה: סטטיסטיקות ודוחות */}
                <div className="dashboard-card">
                    <h2>System Reports</h2>
                    <p>Access system statistics and reports</p>
                    <Link to="/reports" className="dashboard-button">View Reports</Link>
                </div>
            </div>
        </div>
    );
};