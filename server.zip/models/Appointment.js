const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema({
    doctorId: {
        type: String,
        required: true
    },
    patientId: {
        type: String,
        required: true
    },
    date: {
        type: String, // בפורמט של תאריך (YYYY-MM-DD)
        required: true
    },
    time: {
        type: String, // בפורמט של שעה (HH:MM)
        required: true
    },
    description: {
        type: String,
        required: true
    },
    canceled: {
        type: Boolean,
        default: false // ברירת מחדל היא שתור חדש אינו מבוטל
    }
}, { timestamps: true });

const Appointment = mongoose.model('Appointment', appointmentSchema);
module.exports = Appointment;