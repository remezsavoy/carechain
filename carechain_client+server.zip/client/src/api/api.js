import axios from "axios";

const API = axios.create({
    baseURL: "http://localhost:5000",
    withCredentials: true // מאפשר שליחת cookies עם כל בקשה
});

export const register = async (userData) => {
    return API.post("/register", userData);
};

export const sendResetToken = async (email) => {
    return API.post("/forgot-password", { email });
};

export const verifyToken = async ({ email, token }) => {
    return API.post("/verify-token", { email, token });
};

export const resetPassword = async ({ email, token, newPassword }) => {
    return API.post("/reset-password", { email, token, newPassword });
};

export const login = async (email, password) => {
    return API.post("/login", { email, password });
};

export const logout = async () => {
    return API.post("/logout");
};


// 🔹 שליפת כל החוזים של רופא לפי `doctorId`
// 🔹 שליפת כל החוזים של רופא לפי `doctorId`
// ✅ קבלת רשימת חוזים של רופא
export const getContractsByDoctor = async (doctorId) => {
    try {
        const response = await API.get(`/contracts/doctor/${doctorId}`);
        console.log("✅ Fetched Contracts:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error fetching contracts:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ אישור חוזה
export const approveContract = async (contractId) => {
    try {
        const response = await API.put(`/contracts/${contractId}/approve`);
        console.log("✅ Contract approved:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error approving contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ עדכון חוזה
export const updateContract = async (contractId, updatedData) => {
    try {
        const response = await API.put(`/contracts/${contractId}`, updatedData);
        console.log("✅ Contract updated:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error updating contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ יצירת חוזה חדש
export const createContract = async (contractData) => {
    try {
        const response = await API.post("/contracts", contractData);
        console.log("✅ New Contract Created:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error creating contract:", error.response?.data || error.message);
        throw error;
    }
};

// ✅ קבלת פרטי משתמש (לשליפת doctorId)
export const getUserDetails = async () => {
    return await API.get("/user-details"); // ✅ שינוי הנתיב
};



// ✅ קבלת חוזים לפי מטופל
export const getContractsByPatient = async (patientId) => {
    try {
        const response = await API.get(`/contracts/patient/${patientId}`);
        console.log("✅ Fetched Contracts for Patient:", response.data);
        return response.data;
    } catch (error) {
        console.error("❌ Error fetching contracts for patient:", error.response?.data || error.message);
        throw error;
    }
};