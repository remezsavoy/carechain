// src/components/CreateContract.js
import React, { useState } from "react";
import axios from "axios";

const CreateContract = () => {
    const [patientName, setPatientName] = useState("");
    const [doctorName, setDoctorName] = useState("");
    const [treatmentDetails, setTreatmentDetails] = useState("");
    const [message, setMessage] = useState("");

    const handleCreateContract = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/contracts", {
                patientName,
                doctorName,
                treatmentDetails,
            });
            setMessage(response.data.message);
        } catch (error) {
            setMessage("Failed to create contract.");
        }
    };

    return (
        <form onSubmit={handleCreateContract}>
            <input
                type="text"
                placeholder="Patient Name"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
            />
            <input
                type="text"
                placeholder="Doctor Name"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
            />
            <textarea
                placeholder="Treatment Details"
                value={treatmentDetails}
                onChange={(e) => setTreatmentDetails(e.target.value)}
            ></textarea>
            <button type="submit">Create Contract</button>
            {message && <p>{message}</p>}
        </form>
    );
};

export default CreateContract;
