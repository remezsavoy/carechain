// src/components/VerifyToken.js
import React, { useState } from "react";
import { verifyToken } from "../api/api";
import { useNavigate, useLocation } from "react-router-dom";
import "./AuthStyles.css";

const VerifyToken = () => {
    const [token, setToken] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const location = useLocation();

    // קבלת האימייל מהפרמטר בנתיב
    const email = new URLSearchParams(location.search).get("email");

    const handleVerifyToken = async (e) => {
        e.preventDefault();
        try {
            await verifyToken({ email, token });
            setError("");
            navigate("/reset-password", { state: { email, token } }); // מעבר עם האימייל והטוקן
        } catch (error) {
            setError(error.response?.data?.error || "Invalid or expired token.");
        }
    };

    return (
        <div className="auth-container">
            <h2>Enter Reset Token</h2>
            <form onSubmit={handleVerifyToken} className="auth-form">
                <input
                    type="text"
                    placeholder="Token"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    required
                />
                <button type="submit">Verify</button>
            </form>
            {error && <p className="error-message">{error}</p>}
        </div>
    );
};

export default VerifyToken;
