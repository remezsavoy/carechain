import React, { useState } from "react";
import { login } from "../api/api";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            await login(email, password); // אין צורך לשמור את ה-token ב-localStorage
            console.log("User logged in");
            // navigate("/dashboard"); // ניווט לעמוד Dashboard לאחר התחברות מוצלחת
            window.location.href = "/dashboard"
        } catch (error) {
            setError("Login failed. Please check your credentials.");
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleLogin} className="login-form">
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <button type="submit">Login</button>
                {error && <p className="error-message">{error}</p>}
            </form>
            <div className="login-footer">
                <Link to="/forgot-password">Forgot Password?</Link>
            </div>
        </div>
    );
};

export default Login;
