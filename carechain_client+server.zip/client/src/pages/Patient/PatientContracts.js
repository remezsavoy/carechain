import React, { useState, useEffect } from "react";
import { getContractsByPatient, createContract, getUserDetails } from "../../api/api";
import "./PatientContracts.css";

const PatientContracts = () => {
    const [contracts, setContracts] = useState([]);
    const [patientId, setPatientId] = useState(""); 
    const [selectedContract, setSelectedContract] = useState(null); 
    const [showNewContractModal, setShowNewContractModal] = useState(false);
    const [formData, setFormData] = useState({
        doctorId: "",
        treatmentType: "",
        description: "",
    });
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    // ✅ שליפת פרטי המטופל
    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await getUserDetails();  
                setPatientId(response.data.idNumber); 
            } catch (err) {
                setError("Failed to fetch user details.");
            }
        };
        fetchUserDetails();
    }, []);

    // ✅ שליפת החוזים של המטופל
    useEffect(() => {
        if (!patientId) return;
        const fetchContracts = async () => {
            try {
                const data = await getContractsByPatient(patientId);
                setContracts(data);
            } catch (err) {
                setError("❌ Failed to load contracts");
            }
        };
        fetchContracts();
    }, [patientId]);

    // ✅ יצירת חוזה חדש
    const handleCreateContract = async (e) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);

        if (!formData.doctorId || !formData.treatmentType || !formData.description) {
            setError("❌ Please fill all fields");
            return;
        }

        try {
            const response = await createContract(patientId, formData.doctorId, formData.treatmentType, formData.description);
            if (response.error) {
                setError(response.error);
            } else {
                setSuccess("✅ Contract created successfully!");
                setContracts([...contracts, response]);
                setShowNewContractModal(false);
                setFormData({ doctorId: "", treatmentType: "", description: "" });
            }
        } catch (err) {
            setError("❌ Error creating contract");
        }
    };

    // ✅ הצגת פרטי החוזה במודל
    const handleViewContract = (contract) => {
        setSelectedContract(contract);
    };

    return (
        <div className="contracts-container">
            <h2>Patient Contracts</h2>

            {error && <p className="error-message">{error}</p>}
            {success && <p className="success-message">{success}</p>}

            {/* 🔹 כפתור ליצירת חוזה */}
            <button className="create-button" onClick={() => setShowNewContractModal(true)}>
                ➕ Create New Contract
            </button>

            {/* 🔹 טבלת חוזים */}
            <h3>Your Contracts</h3>
            {contracts.length === 0 ? (
                <p>No contracts found.</p>
            ) : (
                <div className="table-wrapper">
                    <table className="contracts-table">
                        <thead>
                            <tr>
                                <th>Contract ID</th>
                                <th>Treatment</th>
                                <th>Description</th>
                                <th>Approved</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {contracts.map((contract) => (
                                <tr key={contract.contractId}>
                                    <td>{contract.contractId}</td>
                                    <td>{contract.treatmentType}</td>
                                    <td>{contract.description}</td>
                                    <td className={contract.isApproved ? "contract-approved" : "contract-not-approved"}>
                                        {contract.isApproved ? "✅ Yes" : "❌ No"}
                                    </td>
                                    <td>
                                        <button className="view-button" onClick={() => handleViewContract(contract)}>
                                            👁 View
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* 🔹 מודל להצגת חוזה */}
            {selectedContract && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Contract Details</h3>
                        <p><strong>Contract ID:</strong> {selectedContract.contractId}</p>
                        <p><strong>Treatment:</strong> {selectedContract.treatmentType}</p>
                        <p><strong>Description:</strong> {selectedContract.description}</p>
                        <p><strong>Approved:</strong> {selectedContract.isApproved ? "✅ Yes" : "❌ No"}</p>
                        <button className="close-button" onClick={() => setSelectedContract(null)}>Close</button>
                    </div>
                </div>
            )}

            {/* 🔹 מודל ליצירת חוזה חדש */}
            {showNewContractModal && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Create New Contract</h3>
                        {error && <p className="error-message">{error}</p>}
                        <form onSubmit={handleCreateContract} className="contract-form">
                            <input
                                type="text"
                                placeholder="Doctor ID"
                                value={formData.doctorId}
                                onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                                required
                            />
                            <input
                                type="text"
                                placeholder="Treatment Type"
                                value={formData.treatmentType}
                                onChange={(e) => setFormData({ ...formData, treatmentType: e.target.value })}
                                required
                            />
                            <textarea
                                placeholder="Description"
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                required
                            />
                            <button type="submit" className="approve-button">✔ Create</button>
                            <button className="close-button" onClick={() => setShowNewContractModal(false)}>Cancel</button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PatientContracts;
