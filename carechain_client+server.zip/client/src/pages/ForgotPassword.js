// src/components/ForgotPassword.js
import React, { useState } from "react";
import { sendResetToken } from "../api/api";
import { useNavigate } from "react-router-dom";
import "./AuthStyles.css";

const ForgotPassword = () => {
    const [email, setEmail] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleForgotPassword = async (e) => {
        e.preventDefault();
        try {
            await sendResetToken(email);
            setError("");
            navigate(`/verify-token?email=${encodeURIComponent(email)}`);
        } catch (error) {
            setError(error.response?.data?.error || "Failed to send reset token.");
        }
    };

    return (
        <div className="auth-container">
            <h2>Forgot Password</h2>
            <form onSubmit={handleForgotPassword} className="auth-form">
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <button type="submit">Submit</button>
            </form>
            {error && <p className="error-message">{error}</p>}
        </div>
    );
};

export default ForgotPassword;
