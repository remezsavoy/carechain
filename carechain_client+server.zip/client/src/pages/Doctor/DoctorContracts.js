import React, { useState, useEffect } from "react";
import { getContractsByDoctor, approveContract, createContract, getUserDetails } from "../../api/api";
import "./DoctorContracts.css"; // ✅ קישור לקובץ העיצוב

const DoctorContracts = () => {
    const [contracts, setContracts] = useState([]);
    const [error, setError] = useState(""); // ❌ שגיאות יוצגו כאן
    const [doctorId, setDoctorId] = useState("");
    const [selectedContract, setSelectedContract] = useState(null);
    const [searchTerm, setSearchTerm] = useState(""); 
    const [newContract, setNewContract] = useState({
        patientId: "",
        treatmentType: "",
        description: ""
    });
    const [showNewContractModal, setShowNewContractModal] = useState(false);

    // Fetch details of the logged-in user
    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await getUserDetails();
                setDoctorId(response.data.idNumber);
            } catch (err) {
                setError("Failed to fetch user details.");
            }
        };
        fetchUserDetails();
    }, []);

    // Fetch contracts of the doctor after user details are fetched
    useEffect(() => {
        if (!doctorId || contracts.length > 0) return;
        const fetchContracts = async () => {
            try {
                const data = await getContractsByDoctor(doctorId);
                setContracts(data);
            } catch (err) {
                setError("Failed to load contracts.");
            }
        };
        fetchContracts();
    }, [doctorId]);

    // 🔍 Filter contracts based on search term
    const filteredContracts = contracts.filter(contract =>
        contract.contractId && contract.contractId.toString().includes(searchTerm) ||
        contract.patientId && contract.patientId.toString().includes(searchTerm) ||
        (contract.treatmentType && contract.treatmentType.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (contract.description && contract.description.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    // ✅ Validate contract data before submitting
    const validateContractData = () => {
        if (!/^\d{9}$/.test(newContract.patientId)) {
            setError("❌ Patient ID must be exactly 9 digits.");
            return false;
        }
        if (!newContract.patientId || Number(newContract.patientId) === 0) {
            setError("❌ Patient ID cannot be 0.");
            return false;
        }
        if (newContract.treatmentType.trim() === "") {
            setError("❌ Treatment Type cannot be empty.");
            return false;
        }
        if (newContract.description.trim() === "") {
            setError("❌ Description cannot be empty.");
            return false;
        }
        setError(""); 
        return true;
    };

    // ✅ Create a new contract
    const handleCreateContract = async () => {
        if (!validateContractData()) return; 

        try {
            console.log("📤 Sending Create Contract Request:", newContract);

            const response = await createContract({
                patientId: Number(newContract.patientId),
                doctorId: Number(doctorId),
                treatmentType: newContract.treatmentType,
                description: newContract.description
            });

            console.log("✅ API Response:", response);

            if (response.success) {
                alert(response.message || "✅ Contract created successfully!");
                setShowNewContractModal(false);
                setNewContract({ patientId: "", treatmentType: "", description: "" });
                setError(""); 
                return;
            }

            console.error("❌ Server did not confirm success:", response);
            setError("❌ Contract creation failed. Please try again.");
        } catch (err) {
            console.error("❌ Error creating contract:", err);
            setError("❌ Failed to create contract. Please try again.");
        }
    };

    // ✅ Approve contract
    const handleApprove = async (contractId) => {
        try {
            console.log(`📤 Sending approval request for Contract ID: ${contractId}`);
            
            const response = await approveContract(contractId); // קריאה לשרת
            
            console.log("✅ Contract approved:", response);
    
            // בדיקה אם התגובה מכילה success=true
            if (response.success) {
                // עדכון הסטטוס של החוזה ברשימה
                setContracts((prevContracts) =>
                    prevContracts.map((contract) =>
                        contract.contractId === contractId ? { ...contract, isApproved: true } : contract
                    )
                );
    
                alert("✅ Contract approved successfully!");
            } else {
                // ❌ אם לא הצלחנו לאשר את החוזה
                console.error("❌ Error approving contract:", response);
                setError("❌ Failed to approve contract.");
            }
        } catch (err) {
            console.error("❌ Error approving contract:", err);
            setError("❌ Failed to approve contract. Please try again.");
        }
    };
    

    return (
        <div className="contracts-container">
            <h2>Doctor Contracts</h2>
            {error && <p className="error-message">{error}</p>}

            {/* 🔍 Contract search input */}
            <input
                type="text"
                className="search-bar"
                placeholder="🔎 Search contracts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />

            {/* Button to create a new contract */}
            <button className="create-button" onClick={() => setShowNewContractModal(true)}>
                ➕ Create New Contract
            </button>

            {filteredContracts.length === 0 ? (
                <p>No contracts found.</p>
            ) : (
                <div className="table-wrapper">
                    <table className="contracts-table">
                        <thead>
                            <tr>
                                <th>Contract ID</th>
                                <th>Patient ID</th>
                                <th>Treatment</th>
                                <th>Description</th>
                                <th>Approved</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredContracts.map((contract) => (
                                <tr key={contract.contractId}>
                                    <td>{contract.contractId}</td>
                                    <td>{contract.patientId}</td>
                                    <td>{contract.treatmentType}</td>
                                    <td>{contract.description}</td>
                                    <td className={contract.isApproved ? "contract-approved" : "contract-not-approved"}>
                                        {contract.isApproved ? "✅ Yes" : "❌ No"}
                                    </td>
                                    <td>
                                        <button className="view-button" onClick={() => setSelectedContract(contract)}>
                                            👁 View
                                        </button>
                                        {!contract.isApproved && (
                                            <button className="approve-button" onClick={() => handleApprove(contract.contractId)}>
                                                ✔ Approve
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* 🔹 Modal for creating a new contract */}
            {showNewContractModal && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Create New Contract</h3>
                        
                        {/* ❌ Show error message in the modal */}
                        {error && <p className="error-message">{error}</p>}
                        
                        <div className="input-group">
                            <input
                                type="number"
                                placeholder="Patient ID"
                                value={newContract.patientId}
                                onChange={(e) => setNewContract({ ...newContract, patientId: e.target.value })}
                            />
                            <input
                                type="text"
                                placeholder="Treatment Type"
                                value={newContract.treatmentType}
                                onChange={(e) => setNewContract({ ...newContract, treatmentType: e.target.value })}
                            />
                        </div>

                        <textarea
                            placeholder="Description"
                            value={newContract.description}
                            onChange={(e) => setNewContract({ ...newContract, description: e.target.value })}
                        ></textarea>

                        <div className="button-group">
                            <button className="approve-button" onClick={handleCreateContract}>✔ Create</button>
                            <button className="close-button" onClick={() => setShowNewContractModal(false)}>Cancel</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DoctorContracts;
