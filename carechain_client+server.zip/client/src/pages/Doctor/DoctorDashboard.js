import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../../api/api";
import "./DoctorDashboard.css"; // שימוש בעיצוב מותאם לרופא

const DoctorDashboard = () =>  {
    const navigate = useNavigate();

    useEffect(() => {
        const checkAuth = async () => {
            try {
                const response = await fetch("http://localhost:5000/auth-check", {
                    method: "GET",
                    credentials: "include",
                });

                if (response.status !== 200) {
                    throw new Error("Not authenticated");
                }
            } catch (error) {
                navigate("/login");
            }
        };

        checkAuth();
    }, [navigate]);

    const handleLogout = async () => {
        try {
            await logout();
            navigate("/");
        } catch (error) {
            console.error("Logout failed:", error);
        }
    };

    return (
        <div className="dashboard-container">
            <header className="dashboard-header">
                <h1>You are a Doctor</h1>
                <p>Manage your medical contracts and appointments</p>
                <button onClick={handleLogout} className="logout-button">Logout</button>
            </header>
            <div className="dashboard-content">
                <div className="dashboard-card">
                    <h2>My Profile</h2>
                    <p>View and edit your professional information</p>
                    <Link to="/profile" className="dashboard-button">Go to Profile</Link>
                </div>
                <div className="dashboard-card">
                    <h2>Patient Contracts</h2>
                    <p>Review, approve, and manage medical contracts</p>
                    <Link to="/contracts" className="dashboard-button">Manage Contracts</Link>
                </div>
                <div className="dashboard-card">
                    <h2>Appointments</h2>
                    <p>Schedule and manage patient appointments</p>
                    <Link to="/appointments" className="dashboard-button">Manage Appointments</Link>
                </div>
                <div className="dashboard-card">
                    <h2>Settings</h2>
                    <p>Adjust your account and notification settings</p>
                    <Link to="/settings" className="dashboard-button">Settings</Link>
                </div>
            </div>
        </div>
    );
};

export default DoctorDashboard;
