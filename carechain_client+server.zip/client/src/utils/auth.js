export const getToken = () => localStorage.getItem("token");
export const getUserType = () => localStorage.getItem("userType");

export const isAuthenticated = () => {
    return !!getToken(); // אם יש טוקן – המשתמש מחובר
};

export const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userType");
    window.location.href = "/login"; // הפנייה למסך התחברות
};
