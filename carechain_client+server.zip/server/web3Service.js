const { ethers } = require("ethers");
require("dotenv").config();
const fs = require("fs");

const provider = new ethers.JsonRpcProvider(process.env.GANACHE_RPC_URL);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const signer = wallet.connect(provider);

const contractABI = JSON.parse(fs.readFileSync("./artifacts/contracts/MedicalContract.sol/MedicalContract.json")).abi;
const contractAddress = process.env.CONTRACT_ADDRESS;
const contract = new ethers.Contract(contractAddress, contractABI, signer);

// 🔹 יצירת חוזה רפואי חדש
async function createMedicalContract(patientId, doctorId, treatmentType, description) {
    try {
        console.log(`🔍 Creating contract for Patient: ${patientId}, Doctor: ${doctorId}`);
        const tx = await contract.createContract(patientId, doctorId, treatmentType, description);
        await tx.wait();
        console.log("✅ Contract created successfully");
    } catch (error) {
        console.error("❌ ERROR creating contract:", error.reason || error);
        throw error;
    }
}

// 🔹 עדכון חוזה לפי `contractId`
async function updateMedicalContract(contractId, newTreatmentType, newDescription) {
    try {
        console.log(`🔍 Updating contract ID: ${contractId}`);
        const tx = await contract.updateContract(contractId, newTreatmentType, newDescription);
        await tx.wait();
        console.log("✅ Contract updated successfully");
    } catch (error) {
        console.error("❌ ERROR updating contract:", error.reason || error);
        throw error;
    }
}

// 🔹 שליפת חוזים לפי `patientId`
async function getContractsByPatient(patientId) {
    try {
        console.log(`🔍 Fetching contracts for Patient ID: ${patientId}`);
        const contracts = await contract.getContractsByPatient(patientId);
        return contracts.map(c => ({
            contractId: Number(c.contractId),
            patientId: Number(c.patientId),
            doctorId: Number(c.doctorId),
            treatmentType: c.treatmentType,
            description: c.description,
            createdAt: new Date(Number(c.createdAt) * 1000).toISOString(),
            lastUpdated: new Date(Number(c.lastUpdated) * 1000).toISOString(),
            isApproved: c.isApproved
        }));
    } catch (error) {
        console.error("❌ ERROR fetching contracts by patient:", error);
        return [];
    }
}

// 🔹 שליפת חוזים לפי `doctorId`
async function getContractsByDoctor(doctorId) {
    try {
        console.log(`🔍 Fetching contracts for Doctor ID: ${doctorId}`);
        const contracts = await contract.getContractsByDoctor(doctorId);
        return contracts.map(c => ({
            contractId: Number(c.contractId),
            patientId: Number(c.patientId),
            doctorId: Number(c.doctorId),
            treatmentType: c.treatmentType,
            description: c.description,
            createdAt: new Date(Number(c.createdAt) * 1000).toISOString(),
            lastUpdated: new Date(Number(c.lastUpdated) * 1000).toISOString(),
            isApproved: c.isApproved
        }));
    } catch (error) {
        console.error("❌ ERROR fetching contracts by doctor:", error);
        return [];
    }
}

// 🔹 אישור חוזה לפי `contractId` – רק הרופא של החוזה יכול לאשר
async function approveMedicalContract(contractId, doctorId) {
    try {
        console.log(`🔍 Approving contract ID: ${contractId} by Doctor ID: ${doctorId}`);
        const tx = await contract.approveContract(contractId, doctorId);
        await tx.wait();
        console.log("✅ Contract approved successfully");
    } catch (error) {
        console.error("❌ ERROR approving contract:", error.reason || error);
        throw error;
    }
}

module.exports = {
    createMedicalContract,
    updateMedicalContract,
    getContractsByPatient,
    getContractsByDoctor,
    approveMedicalContract
};
