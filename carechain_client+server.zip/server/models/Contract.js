// models/Contract.js
const mongoose = require("mongoose");

const contractSchema = new mongoose.Schema({
    patientName: String,
    doctorName: String,
    treatmentDetails: String,
    isApproved: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Contract", contractSchema);
