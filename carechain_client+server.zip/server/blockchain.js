const Web3 = require('web3').default;
require('dotenv').config();

// Check if BLOCKCHAIN_RPC_URL is defined
if (!process.env.BLOCKCHAIN_RPC_URL) {
    console.error("❌ ERROR: BLOCKCHAIN_RPC_URL is not defined in the .env file.");
    process.exit(1);
}

// Create Web3 instance correctly for Web3.js 4.x
const web3 = new Web3(process.env.BLOCKCHAIN_RPC_URL);

console.log("✅ Web3 initialized successfully!");
module.exports = { web3 };
