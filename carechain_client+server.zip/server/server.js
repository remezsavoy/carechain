const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require('fs');
const cors = require('cors');
const http = require('http');
const cookieParser = require("cookie-parser");
const nodemailer = require("nodemailer");
const { findOne, createConnection } = require("./api/mongodb");
const { authenticateToken, authenticateAdminToken } = require("./middleware/jwt");
require('dotenv').config()
const { User } = require('./api/mongodb'); // נתיב למודל המשתמש שלך
const app = express();
const PORT = 5000; // הגדרת הפורט
const {
    createMedicalContract,
    updateMedicalContract,
    getContractsByPatient,
    getContractsByDoctor,
    approveMedicalContract
} = require("./web3Service");

// פונקציית חיבור ל-MongoDB
  
  // יצירת שרת HTTP
  http.createServer(app).listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
  
  // חיבור ל-MongoDB
  createConnection()
    .then(() => console.log('MongoDB Connected OK'))
    .catch(e => console.log(`MongoDB Connection ERROR - ${e}`));


    console.log("🛠 Checking function imports...");
    console.log("✅ getTotalContracts type:", typeof getTotalContracts);
    
app.use(cors({
    origin: "http://localhost:3000",
    credentials: true
}));
app.use(express.json());
app.use(cookieParser());

// פונקציה ליצירת טוקן רנדומלי
function generateToken() {
    return Math.random().toString(36).substr(2, 8);
}

// פונקציה לשליחת מייל (באמצעות nodemailer)
function sendEmail(to, message) {
    const transporter = nodemailer.createTransport({
        service: "Gmail",
        auth: {
            user: "supp.carechain@gmail.com",
            pass: "hrut ejwa qwpq ldne"
        }
    });

    const mailOptions = {
        from: "supp.carechain@gmail.com",
        to,
        subject: "Password Reset Token",
        text: message
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.error("Error sending email:", error);
        }
        console.log("Email sent:", info.response);
    });
}

// מסלול לשליחת טוקן איפוס סיסמא
app.post("/forgot-password", async (req, res) => {
    const { email } = req.body;

    try {
        const user = await findOne({ email });
        if (!user) {
            return res.status(400).json({ error: "User not found" });
        }

        const resetToken = generateToken();
        user.resetToken = resetToken;
        user.resetTokenExpiry = Date.now() + 3600000; // שעה אחת
        await user.save();

        sendEmail(user.email, `Your password reset token is ${resetToken}`);

        res.json({ message: "Reset token sent to your email" });
    } catch (error) {
        console.error("Error sending reset token:", error);
        res.status(500).json({ error: "Failed to send reset token" });
    }
});

// מסלול בשרת לשינוי סיסמה עם בדיקת טוקן
app.post("/reset-password", async (req, res) => {
    const { email, token, newPassword } = req.body;

    try {
        const user = await findOne({
            email,
            resetToken: token,
            resetTokenExpiry: { $gt: Date.now() }
        });

        if (!user) {
            return res.status(400).json({ error: "Invalid or expired reset token" });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.passwordHistory.push(user.password);
        if (user.passwordHistory.length > 3) user.passwordHistory.shift();
        user.password = hashedPassword;
        user.resetToken = null;
        user.resetTokenExpiry = null;

        await user.save();
        res.json({ message: "Password updated successfully" });
    } catch (error) {
        console.error("Password reset error:", error);
        res.status(500).json({ error: "Failed to reset password." });
    }
});

app.post("/register", async (req, res) => {
    const { firstName, lastName, email, phone, idNumber, password, birthDate } = req.body;

    try {
        // בדיקה אם תעודת זהות כבר קיימת
        const existingUser = await findOne({ idNumber });
        if (existingUser) {
            return res.status(400).json({ error: "ID Number is already registered." });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({
            firstName,
            lastName,
            email,
            phone,
            idNumber,
            password: hashedPassword,
            birthDate,
            userType: 2,
        });

        // Log the registered user's information to the console
        console.log("New user registered:", {
            firstName,
            lastName,
            email,
            phone,
            idNumber,
            birthDate,
        });

        await user.save();

        res.json({ message: "User registered successfully" });
    } catch (error) {
        console.error("Registration error:", error);
        res.status(500).json({ error: "Registration failed. Please try again." });
    }
});



// פונקציה לבדיקת תקינות קלט
function validateInputs({ firstName, lastName, email, phone, idNumber, password, birthDate }) {
    const nameRegex = /^[A-Za-zא-ת]+$/;
    const idRegex = /^\d{9}$/;
    const phoneRegex = /^\d{10}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!nameRegex.test(firstName) || !nameRegex.test(lastName)) {
        return "First and last names should contain letters only.";
    }
    if (!emailRegex.test(email)) {
        return "Invalid email format.";
    }
    if (!idRegex.test(idNumber)) {
        return "ID Number should contain exactly 9 digits.";
    }
    if (!phoneRegex.test(phone)) {
        return "Phone number should contain exactly 10 digits.";
    }
    const passwordError = validatePassword(password);
    if (passwordError) {
        return passwordError;
    }
    if (!birthDate) {
        return "Birth date is required.";
    }

    return null;
}

// פונקציה לבדיקת תקינות סיסמה
function validatePassword(password) {
    if (password.length < 8) {
        return "Password must be at least 8 characters long.";
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return "Password must contain at least one special character.";
    }
    if (!/[a-z]/.test(password)) {
        return "Password must contain at least one lowercase letter.";
    }
    if (!/[A-Z]/.test(password)) {
        return "Password must contain at least one uppercase letter.";
    }
    if (!/[0-9]/.test(password)) {
        return "Password must contain at least one number.";
    }
    return null;
}

// מסלול התחברות
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await findOne({ email });
    if (!user) return res.status(400).json({ error: "User not found" });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(400).json({ error: "Invalid password" });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.cookie("token", token, {
        httpOnly: true,
        secure: true, // יש להשתמש בזה כאשר האתר ב-HTTPS
        sameSite: "Strict", // מגביל שליחה רק לאותו דומיין
        maxAge: 3600000 // שעה
    });

    res.json({ message: "Logged in successfully", userType: user.userType });
});


app.post("/logout", (req, res) => {
    res.clearCookie("token");
    res.json({ message: "Logged out successfully" });
});



app.get("/auth-check", authenticateToken, (req, res) => {
    res.status(200).json({ message: "Authenticated", userType: req.user.userType });
});
app.get("/auth-check-admin", authenticateAdminToken, (req, res) => {
    res.status(200).json({ message: "Authenticated" });
});

app.get("/user-details", authenticateToken, async (req, res) => {
    try {
        res.json(req.user);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch user details." });
    }
});

// 🔹 יצירת חוזה רפואי חדש – מחייב טוקן
// 🔹 יצירת חוזה רפואי חדש – מחייב טוקן
app.post("/contracts", authenticateToken, async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({ error: "❌ Unauthorized: No token provided" });
        }
        //admin=0 doctor=1
        if (req.user.userType !== 1 && req.user.userType !== 0) {
            return res.status(403).json({ error: "❌ Access denied. Only doctors and admins can create contracts." });
        }

        const { patientId, doctorId, treatmentType, description } = req.body;
        await createMedicalContract(patientId, doctorId, treatmentType, description);
        res.status(201).send("✅ Contract created successfully");
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});



// 🔹 עדכון חוזה – מחייב טוקן
app.put("/contracts/:id", authenticateToken, async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({ error: "❌ Unauthorized: No token provided" });
        }

        const { newTreatmentType, newDescription } = req.body;
        await updateMedicalContract(req.params.id, newTreatmentType, newDescription);
        res.status(200).send("✅ Contract updated successfully");
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 🔹 שליפת חוזים לפי `patientId` – מחייב טוקן
app.get("/contracts/patient/:patientId", authenticateToken, async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({ error: "❌ Unauthorized: No token provided" });
        }

        const contracts = await getContractsByPatient(req.params.patientId);
        res.status(200).json(contracts);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 🔹 שליפת חוזים לפי `doctorId` – מחייב טוקן
app.get("/contracts/doctor/:doctorId", authenticateToken, async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({ error: "❌ Unauthorized: No token provided" });
        }

        const contracts = await getContractsByDoctor(req.params.doctorId);
        res.status(200).json(contracts);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 🔹 אישור חוזה – מחייב טוקן
app.put("/contracts/:id/approve", authenticateToken, async (req, res) => {
    try {
        const contractId = Number(req.params.id);
        const doctorId = req.user.idNumber;

        console.log("🔍 Headers:", req.headers);
        console.log("🧐 req.body:", req.body);

        // בדיקה אם contractId ו-doctorId תקינים
        if (isNaN(contractId) || isNaN(doctorId)) {
            console.log(`🔍 Invalid contract ID: ${contractId}, Doctor ID: ${doctorId}`);
            return res.status(400).json({ success: false, error: "❌ Invalid contractId or doctorId" });
        }

        console.log(`🔍 Approving contract ID: ${contractId}, Doctor ID: ${doctorId}`);

        await approveMedicalContract(contractId, doctorId);

        // החזרת תגובה ברורה עם success
        res.status(200).json({ success: true, message: "✅ Contract approved successfully" });
    } catch (error) {
        console.error("❌ Error approving contract:", error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
});









