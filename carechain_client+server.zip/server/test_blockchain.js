const { web3 } = require("./blockchain");

async function checkConnection() {
    try {
        const blockNumber = await web3.eth.getBlockNumber();
        console.log("connected to blockchain", blockNumber);
    } catch (error) {
        console.error(" Error: can't connect to blockchain", error);
    }
}

checkConnection();
